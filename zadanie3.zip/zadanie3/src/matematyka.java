public class matematyka {
}
