public class zajecia {
    public String nazwazajec;
}
