import java.util.ArrayList;

public class student {
    public String imie;
    public String nazwisko;
    public int numerindeksu;
    public String email;
    public String adres;
    public ArrayList<Double> oceny;
    public zajecia mojezajecia;
    public zajecia2 mojezajecia2;
    public zajecia3 mojezajecia3;
    public double obliczaniesredniej(){
        double avg=0;
        for (int i=0 ; i<oceny.size(); i++){
            avg+=oceny.get(i);
        }
        avg/=oceny.size();

        return avg;
    }


}

