public class zajecia3 {
    public String nazwazajec3;
}
