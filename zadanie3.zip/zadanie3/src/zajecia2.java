public class zajecia2 {
    public String nazwazajec2;
}
