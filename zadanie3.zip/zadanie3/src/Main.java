import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        zajecia zajecia = new zajecia();
        zajecia.nazwazajec="matematyka";

        zajecia2 zajecia2 = new zajecia2();
        zajecia2.nazwazajec2 = "informatyka";

        zajecia3 zajecia3 = new zajecia3();
        zajecia3.nazwazajec3 = "angielski";


        student st = new student();
        st.imie = "Jacek";
        st.nazwisko = "Markowicz";
        st.numerindeksu = 3457;
        st.email = "jacmar3457@spoko.pl";
        st.adres = "Warszawa koszykowa 23 ";
        st.mojezajecia=zajecia;
        st.oceny=new ArrayList<>();
        st.oceny.add(3.5);
        st.oceny.add(2.5);
        st.oceny.add(3.0);
        st.oceny.add(4.0);
        st.oceny.add(5.0);
        double srednia=st.obliczaniesredniej();

        student st2 = new student();
        st.imie = "Basia";
        st.nazwisko = "Piłka";
        st.numerindeksu = 3459;
        st.email = "baspil3457@spoko.pl";
        st.adres = "Warszawa koszykowa 4 ";
        st.mojezajecia2=zajecia2;
        st.oceny=new ArrayList<>();
        st.oceny.add(3.0);
        st.oceny.add(2.0);
        st.oceny.add(3.5);
        st.oceny.add(4.5);
        st.oceny.add(4.5);
        double srednia2=st.obliczaniesredniej();

        student st3 = new student();
        st.imie = "Michal";
        st.nazwisko = "siatka";
        st.numerindeksu = 3458;
        st.email = "micsia3457@spoko.pl";
        st.adres = "Warszawa koszykowa 5 ";
        st.mojezajecia3=zajecia3;
        st.oceny=new ArrayList<>();
        st.oceny.add(3.0);
        st.oceny.add(2.0);
        st.oceny.add(3.5);
        st.oceny.add(4.5);
        st.oceny.add(4.5);
        double srednia3=st.obliczaniesredniej();


    }
}