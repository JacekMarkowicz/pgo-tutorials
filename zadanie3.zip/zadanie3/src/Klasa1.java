public class Klasa1 {
    public String matematyka;
}
